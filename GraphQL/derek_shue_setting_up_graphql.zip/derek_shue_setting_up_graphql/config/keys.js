module.exports = {
    mongoURI: 'mongodb+srv://derek2:JhU4JRNJ9o16C9VG@cluster0-oyx1b.mongodb.net/test?retryWrites=true&w=majority'
};
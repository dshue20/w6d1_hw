module.exports = {
    mongoURI: 'mongodb+srv://derek2:JhU4JRNJ9o16C9VG@cluster0-oyx1b.mongodb.net/test?retryWrites=true&w=majority',
    secretOrKey: '14f1dfee-3d7a-11ea-b77f-2e728ce88125'
};
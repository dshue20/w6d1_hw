class Stack

  attr_accessor :arr

  def initialize
    @arr = []
  end

  def push(el)
    @arr << el
    el
  end

  def pop
    @arr.pop
  end

  def peek
    @arr[-1]
  end

end

class Queue

  attr_accessor :arr

  def initialize
    @arr = []
  end

  def enqueue(el)
    @arr << el
    el
  end

  def dequeue
    @arr.shift
  end

  def peek
    @arr[0]
  end
end

class Map

  attr_accessor :arr

  def initialize
    @arr = []
  end

  def set(key, value)
    indices = @arr.index { |ele| ele[0] == key }
    if indices
      @arr[indices][1] = value
    else
      @arr << [key, value]
    end
    value
  end

  def get(key)
    @arr.each { |ele| return ele[1] if ele[0] == key }
    nil
  end

  def delete(key)
    val = get(key)
    @arr.reject! { |ele| ele[0] == key }
    val
  end

  def show
    @arr
  end
end
